package middleware

import (
	"net/http"
	"strings"

	"github.com/developermahmoud/elsystm-backend/config"
	"github.com/developermahmoud/elsystm-backend/models"
	"github.com/gin-gonic/gin"
)

var db = config.SetupDatabase()

func IsAuthentication() gin.HandlerFunc {
	return func(c *gin.Context) {
		authorization := c.Request.Header["Authorization"]
		if len(authorization) == 0 {
			c.AbortWithStatus(http.StatusUnauthorized)
			return
		}

		// Split token
		token := strings.Split(authorization[0], " ")
		if token == nil {
			c.AbortWithStatus(http.StatusUnauthorized)
			return
		}

		// Check in model
		var user models.UserToken

		db.Where("token = ?", token[1]).First(&user)

		if user.ID == 0 {
			c.AbortWithStatus(http.StatusUnauthorized)
			return
		}

		c.Set("user", user.UserId)

		c.Next()
	}
}
