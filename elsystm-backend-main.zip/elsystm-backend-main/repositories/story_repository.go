package repositories

import (
	"log"
	"net/http"
	"os"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3/s3manager"
	"github.com/developermahmoud/elsystm-backend/dto"
	"github.com/developermahmoud/elsystm-backend/models"
	"github.com/developermahmoud/elsystm-backend/util"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type StoryRepository interface {
	Store(c *gin.Context)
}

type storyRepository struct {
	db *gorm.DB
}

func NewStoryRepository(db *gorm.DB) StoryRepository {
	return &storyRepository{db: db}
}

func (r storyRepository) Store(c *gin.Context) {
	var storyDTO dto.StoryCreate
	var story models.Story
	var storyMedia models.StoryMedia

	if err := c.ShouldBind(&storyDTO); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"errors": util.Validation(err)})
		return
	}

	userId := c.MustGet("user").(uint64)
	sess := c.MustGet("sess").(*session.Session)
	uploader := s3manager.NewUploader(sess)

	MyBucket := os.Getenv("AWS_BUCKET_NAME")

	file, header, err := c.Request.FormFile("file")
	if err != nil {
		log.Fatal(err)
	}
	filename := header.Filename

	//upload to the s3 bucket
	up, err := uploader.Upload(&s3manager.UploadInput{
		Bucket: aws.String(MyBucket),
		ACL:    aws.String("public-read"),
		Key:    aws.String(filename),
		Body:   file,
	})

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error":    "Failed to upload file",
			"uploader": up,
		})
		return
	}

	// Store Story
	story.Content = storyDTO.Content
	story.Type = storyDTO.Type
	story.UserId = userId
	r.db.Create(&story)

	// Store Media
	storyMedia.Path = filename
	storyMedia.StoryID = story.ID
	storyMedia.UserID = userId
	r.db.Create(&storyMedia)

	c.JSON(http.StatusCreated, util.GenerateResponse(story, true, "Uploded"))
}
