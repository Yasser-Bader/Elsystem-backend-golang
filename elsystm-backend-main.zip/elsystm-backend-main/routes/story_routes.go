package routes

import (
	"github.com/developermahmoud/elsystm-backend/controllers"
	"github.com/gin-gonic/gin"
)

var controller controllers.StoryController

func SetupStoryRoute(route *gin.Engine) {
	api := route.Group("/v1/stories")
	{
		api.POST("/", controller.Store)
	}
}
