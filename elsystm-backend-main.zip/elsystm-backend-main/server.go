package main

import (
	"github.com/developermahmoud/elsystm-backend/middleware"
	"github.com/developermahmoud/elsystm-backend/routes"
	"github.com/developermahmoud/elsystm-backend/util"
	"github.com/gin-gonic/gin"
)

func main() {

	server := gin.Default()

	// AWS Session
	sess := util.ConnectAws()

	// Added AWS session to app
	server.Use(func(c *gin.Context) {
		c.Set("sess", sess)
		c.Next()
	})

	// Enable CORS
	server.Use(middleware.CORSMiddleware())

	// Check if authenticate
	server.Use(middleware.IsAuthentication())

	// Story Route
	routes.SetupStoryRoute(server)

	server.Run(":6060")
}
