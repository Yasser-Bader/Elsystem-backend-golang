package services

import (
	"github.com/developermahmoud/elsystm-backend/repositories"
	"github.com/gin-gonic/gin"
)

type storyService struct {
	repositories repositories.StoryRepository
}

func NewStoryService(r repositories.StoryRepository) *storyService {
	return &storyService{r}
}

func (s *storyService) Store(c *gin.Context) {
	s.repositories.Store(c)
}
