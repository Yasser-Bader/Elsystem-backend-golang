package dto

type StoryCreate struct {
	Content string `form:"content" binding:"required"`
	Type    string `form:"type" binding:"required"`
}
