package controllers

import (
	"github.com/developermahmoud/elsystm-backend/config"
	"github.com/developermahmoud/elsystm-backend/repositories"
	"github.com/developermahmoud/elsystm-backend/services"
	"github.com/gin-gonic/gin"
)

type StoryController struct{}

var db = config.SetupDatabase()
var repository = repositories.NewStoryRepository(db)
var service = services.NewStoryService(repository)

func (StoryController) Store(c *gin.Context) {
	service.Store(c)
}
