package models

import (
	"time"

	"github.com/developermahmoud/elsystm-backend/datatypes"
)

type Story struct {
	ID             uint64 `gorm:"primaryKey"`
	CreatedAt      time.Time
	UpdatedAt      time.Time
	UserId         uint64
	Type           string `sql:"type:ENUM('cover','avatar')"`
	Content        string
	CustomProperty datatypes.JSON
}
