package models

import (
	"time"
)

type StoryMedia struct {
	ID        uint64 `gorm:"primaryKey"`
	CreatedAt time.Time
	UpdatedAt time.Time
	UserID    uint64
	StoryID   uint64
	Path      string `gorm:"type:varchar(150)"`
}
