package models

import (
	"time"
)

type StoryUser struct {
	ID         uint64 `gorm:"primaryKey"`
	CreatedAt  time.Time
	UpdatedAt  time.Time
	UserId     uint64
	FollowerID uint64
	Status     bool
}
