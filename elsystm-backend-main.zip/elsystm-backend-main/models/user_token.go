package models

type UserToken struct {
	ID        int
	Token     string
	UserId    uint64
	CreatedAt string
	UpdatedAt string
}
